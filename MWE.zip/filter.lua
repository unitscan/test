local file = PANDOC_STATE.input_files[1]

current_dir=io.popen"cd":read'*l'

function file_exists(name)
    local f = io.open(name, "r")
    if f ~= nil then
        io.close(f)
        return true
    else
        return false
    end
end

function lines_from(file)
    if not file_exists(file) then
        return {}
    end
    local lines = {}
    for line in io.lines(file) do
        lines[#lines + 1] = line
    end
    return lines
end

local lines = lines_from(file)

section, figure, fcounter, stop, newfile = 0, 0, 0, 0

local counter, result = 0, string.char(0)

function import(file,newfile)
	local temp = "temp.tex"
	io.output(temp)
	lines = lines_from(file)
	for i = 1, stop-1 do
		io.write(lines[i], "\n")
	end
	lines = lines_from(newfile)
	for j = 1, #lines do
		io.write(lines[j], "\n")
	end
	lines = lines_from(file)
	for k = stop+1, #lines do
		io.write(lines[k], "\n")
	end
	io.close()
	os.execute("ren temp.tex merged.tex") 
end

local equation, eq_section, ecounter, tags = 0, 0, 0, {}

for j = 1, #lines do --Math can't read current section
	if string.sub(lines[j],1,7) == "\\import" then
		stop = j
		newfile = file
		file = string.sub(lines[j],13,-2)
		import(newfile,file)
		break
	end
	if string.find(lines[j],"\\section{") then
		eq_section = eq_section + 1
		if eq_section > 1 then
			equation = 0
		end
		local k = j + 1
		while lines[k] and not string.find(lines[k],"\\section{") do
			if lines[k] == "\\begin{equation}" then
				equation = equation + 1
				table.insert(tags,eq_section.."."..equation)
			end
			if lines[k]:sub(1,2) == "$$" or lines[k]:sub(1,2) == "\\[" or lines[k] == "\\begin{equation*}" then
				table.insert(tags,false)
			end
			k = k + 1
		end
	end
end

function Math(el)
    if (el.mathtype == "DisplayMath") then
		ecounter = ecounter + 1
		io.output("output.tex")
		io.write("\\documentclass[preview]{standalone}", "\n")
		local i = 2
		for k, v in pairs(lines) do
			while not string.find(lines[i], "\\begin{document}") do
				io.write(lines[i], "\n") -- write preamble
				i = i + 1
			end
		end
		io.write("\\begin{document}", "\n")
		io.write("\\vspace{4mm}", "\n")
		io.write("\\begin{minipage}{50em}", "\n")
		io.write("\\vspace{3mm}", "\n")
		io.write("\\begin{equation*}", "\n")
		io.write(el.text, "\n")
		if tags[ecounter] then io.write("\\tag{"..tags[ecounter].."}", "\n") end
		io.write("\\end{equation*}", "\n")
		io.write("\\end{minipage}", "\n")
		io.write("\\vspace{4mm}", "\n")
		io.write("\\end{document}", "\n")
		io.close()
		os.execute("pdflatex output.tex & convert -density 1024 output.pdf -alpha off eq"..ecounter..".png")
		return {
			pandoc.Image({},"eq"..ecounter..".png"),
		}
	end
end

function Header(el)
	if el.level == 1 then
		section = section + 1
		equation, figure = 0, 0
	end
end

local resize

function RawInline(el)
	if string.find(el.text,"\\ce{") then
		return pandoc.Math("InlineMath","\\mathrm{"..string.match(el.text, "{(.*)}").."}")
	end
end

function Figure(fig)
	local temp
	for k,v in pairs(fig.caption) do
		for key, value in pairs(fig.caption) do
			value:walk {
				Plain = function(plain)
					temp = plain.content
				end
			}
		end
	end
	fig:walk {
		RawBlock = function(el)
			if string.find(el.text,"\\begin{tikzpicture}") or string.find(el.text,"\\chemfig") then
			io.output("C:/Logs/output.tex")
			io.write("\\documentclass[preview]{standalone}", "\n")
			fcounter, figure = fcounter + 1, figure + 1
			caption = {
				[1] = pandoc.Strong(pandoc.Str("Figura "..section.."."..figure..string.char(32)))
			}
			for n, item in pairs(temp) do
				caption[n+1] = item
			end
			local i = 2
			for k, v in pairs(lines) do
				while not string.find(lines[i], "\\begin{document}") do
					io.write(lines[i], "\n") -- write preamble
					i = i + 1
				end
			end
			io.write("\\begin{document}", "\n")
			io.write("\\begin{minipage}{50em}", "\n")
			io.write("\\centering", "\n")
			io.write("\\vspace{0.5mm}", "\n")
			io.write(el.text)
			io.write("\\vspace{0.5mm}", "\n")
			io.write("\\end{minipage}", "\n")
			io.write("\\end{document}", "\n")
			io.close()
			
			--remove the ugly \begin{tikzpicture} thick rendering in standalone format
			--just remove lines from 167 to 181 of you need it
			local output = io.open('output.tex', 'r')
			local fileContent = {}
			for line in output:lines() do
				table.insert (fileContent, line)
			end
			io.close(output)
			for k,v in pairs (fileContent) do
				fileContent[k] = (fileContent[k]):match("(.*tikzpicture})") or fileContent[k] 
			end
			output = io.open('output.tex', 'w')
			for index, value in ipairs(fileContent) do
				output:write(value..'\n')
			end
			io.close(output)
			
			os.execute("pdflatex output.tex & convert -density 1024 output.pdf -alpha off fig"..section..figure..".png")
			end
		end
	}
	return { pandoc.Image({},"fig"..section..figure..".png"), pandoc.Inlines(caption) }
end